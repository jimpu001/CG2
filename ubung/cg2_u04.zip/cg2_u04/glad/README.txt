This GL loader source code was automatically created with glad, which can be
found at https://github.com/Dav1dde/glad

We did use the (not yet released) glad2 version and the following parameters
python3 -m glad --api 'gl:core=4.3' --out-path glag c --alias

